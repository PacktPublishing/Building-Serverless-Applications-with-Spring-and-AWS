package com.mtdevuk;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

public class SpringLambdaHandler extends SpringBootRequestHandler<String, String>{

}
