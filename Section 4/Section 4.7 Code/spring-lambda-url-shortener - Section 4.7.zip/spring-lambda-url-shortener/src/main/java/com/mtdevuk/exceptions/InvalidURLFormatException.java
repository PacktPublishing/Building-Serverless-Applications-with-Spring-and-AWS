package com.mtdevuk.exceptions;

public class InvalidURLFormatException extends RuntimeException {
}
